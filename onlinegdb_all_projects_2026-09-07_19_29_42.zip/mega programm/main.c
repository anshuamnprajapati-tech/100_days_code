/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
	int n,ch;
	printf("enter a number :");
	scanf("%d", &n);

	printf("Enter a choice number :");
	scanf("%d", &ch);
	switch(ch) {
	case 1:
		for(int i=1; i<=n; i++) {
			for(int j=1; j<=n; j++) {
				printf("*");
			}

		}
		printf("\n");
		break;
	case 2:
		for(int i=1; i<=n; i++) {
			for(int j=1; j<+i; j++) {
				printf("*");
			}
			printf("\n");
		}
		break;
	case 3:
		for(int i=n; i>=1; i--) {
			for(int j=1; j<=i; j++) {
				printf("*");
			}
			printf("\n");
		}
		break;
	case 4:
		for(int i=1; i<=n; i++) {
			for(int j=1; j<=n-i; j++) {
				printf(" ");
			}
			for(int j=1; j<=i; j++) {
				printf("* ");
			}
			printf("\n");
		}
		break;
	case 5:
		for(int i=1; i<=n; i++) {
			for(int j=1; j<=i; j++) {
				printf("%d", j);
			}
			printf("\n");
		}
		break;
	case 6:
		for(int i=n; i>=1; i++) {
			for(int j=n; j>=i; j++) {
				printf("*");
			}
			printf("\n");
		}
		break;
	case 7:
		int count=0;
		for(int i=1; i<=n; i++) {
			for(int j=1; j<=i; j++) {
				count++;
				printf("%d", count);
			}
			printf("\n");
		}
		break;
	case 8:
		for(int i=1; i<=n; i++) {
			for(int j=1; j<=n-i; j++) {
				printf(" ");
			}
			for(int j=1; j<=n; j++) {
				printf("*");
			}
			printf("\n");
		}
		break;
	case 9:
		for(int i=1; i<=n; i++) {
			for(int j=1; j<=n; j++) {
				if(i==1||i==n||j==1||j==n) {
					printf("*");
				}
				else {
					printf(" ");
				}
			}
			printf("\n");
		}
		break;
	default :
		printf("Invalid choice");

	}

	return 0;
}
