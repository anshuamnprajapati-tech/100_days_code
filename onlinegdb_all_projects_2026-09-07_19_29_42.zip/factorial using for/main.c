/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
   int n, i=1;
   unsigned long factorial = 1;
   printf("Enter a number :");
   scanf("%d", &n);
   for(int i=1; i<=n; i++){
       factorial*=i;
       
   }
   printf("Factorial of number is :%llu", factorial);

    return 0;
}
