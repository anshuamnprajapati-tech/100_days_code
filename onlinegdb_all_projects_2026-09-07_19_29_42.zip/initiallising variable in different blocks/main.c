/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
void block() {
    int a = 10;
    {
        int b = 8;
        printf("Value of a: %d\n", a );
        printf("Value of b is %d\n", b);
    }
    printf("Value of a is : %d\n", a);
}
int main()
{
    block();
    return 0;
}
