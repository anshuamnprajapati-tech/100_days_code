/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    /* wap to enter number till user wants and at the end displayu the count of positive neegative 
    and zeroes enterd*/
    int n, positive=0, negative=0, zeroes=0;
    char ch;
    do{
        printf("Enter a number :");
        scanf("%d", &n);
        if(n>0){
            positive++;
        }
        else if(n<0){
            negative++;
        }
        else{
            zeroes++;
        }
        printf("Do you want to enter another number? (y/n): ");
        scanf(" %c", &ch);
        }while(ch=='y' || ch=='Y');
    
    printf("number of positive integer is %d\n", positive);
    printf("Number of negative integer is %d\n", negative);
    printf("Number of zeroes is %d\n", zeroes);
    

    return 0;
}