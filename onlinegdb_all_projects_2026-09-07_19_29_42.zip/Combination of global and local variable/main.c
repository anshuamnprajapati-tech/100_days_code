/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int a=55; //global variable
void func() {
    int b=5;//local variable
    int sum = a+b;
    printf("Sum of global and local variable is = %d\n", sum);
    
    
}
void next() {
    int c=50;
    int sub = a-c;
    printf("Diference in gobal and local variable is = %d\n", sub);
}

int main()
{
     func();
     next();
    return 0;
}
