/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int n,  i=1;
    unsigned long factorial =1;
    printf("Enter a number :");
    scanf("%d", &n);
    while(i<=n){
        factorial*=i;
        i++;
    }
    printf("Factorial of a numaber is : %llu", factorial);

    return 0;
}